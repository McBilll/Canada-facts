<?php

/**
 * webtrees: online genealogy
 * Copyright (C) 2020 webtrees development team
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */ 
 
declare(strict_types=1);

namespace McBill\WebtreesModules\History\canada_facts;

use Fisharebest\Localization\Translation;
use Fisharebest\Webtrees\I18N;
use Fisharebest\Webtrees\Module\AbstractModule;
use Fisharebest\Webtrees\Module\ModuleCustomInterface;
use Fisharebest\Webtrees\Module\ModuleCustomTrait;
use Fisharebest\Webtrees\Module\ModuleHistoricEventsTrait;
use Fisharebest\Webtrees\Module\ModuleHistoricEventsInterface;
use Illuminate\Support\Collection;

/** 
 * 
 * 
 */
return new class extends AbstractModule implements ModuleCustomInterface, ModuleHistoricEventsInterface {
    use ModuleCustomTrait;
    use ModuleHistoricEventsTrait;

    public const CUSTOM_TITLE = 'Canadian Facts and History';

    public const CUSTOM_AUTHOR = 'McBill';
    
    public const CUSTOM_WEBSITE = 'UNSUPPORTED';
    
    public const CUSTOM_VERSION = '1.0.0.0';

    public const CUSTOM_LAST = 'UNSUPPORTED';

    /**
     * Constructor.  The constructor is called on *all* modules, even ones that are disabled.
     * This is a good place to load business logic ("services").  Type-hint the parameters and
     * they will be injected automatically.
     */
    public function __construct()
    {
        // NOTE:  If your module is dependent on any of the business logic ("services"),
        // then you would type-hint them in the constructor and let webtrees inject them
        // for you.  However, we can't use dependency injection on anonymous classes like
        // this one. For an example of this, see the example-server-configuration module.
    }

    /**
     * Bootstrap.  This function is called on *enabled* modules.
     * It is a good place to register routes and views.
     *
     * @return void
     */
    public function boot(): void
    {
    }

    /**
     * How should this module be identified in the control panel, etc.?
     *
     * @return string
     */
    public function title(): string
    {
        return self::CUSTOM_TITLE;
    }

    /**
     * A sentence describing what this module does.
     *
     * @return string
     */
    public function description(): string
    {
        return I18N::translate('Canadian Facts');
    }

    /**
     * The person or organisation who created this module.
     *
     * @return string
     */
    public function customModuleAuthorName(): string
    {
        return self::CUSTOM_AUTHOR;
    }

    /**
     * The version of this module.
     *
     * @return string
     */
    public function customModuleVersion(): string
    {
        return self::CUSTOM_VERSION;
    }

    /**
     * A URL that will provide the latest version of this module.
     *
     * @return string
     */
        public function customModuleLatestVersionUrl(): string
    {
        return self::CUSTOM_LAST;
    }

    /**
     * Where to get support for this module.  Perhaps a github respository?
     *
     * @return string
     */
    public function customModuleSupportUrl(): string
    {
        return self::CUSTOM_WEBSITE;
    }

    /**
     * Should this module be enabled when it is first installed?
     *
     * @return bool
     */
    public function isEnabledByDefault(): bool
    {
        return false;
    }

    /**
     * Where does this module store its resources
     *
     * @return string
     */
    public function resourcesFolder(): string
    {
        return __DIR__ . '/resources/';
    }
    
    /**
     * Additional/updated translations.
     *
     * @param string $language
     *
     * @return string[]
     */
    
   

    /**
     * All events provided by this module.
     * 
     * Each line is a GEDCOM style record to describe an event (EVEN), including newline chars (\n)
     *      1 EVEN <title>
     *      2 TYPE <short category name>
     *      2 DATE <date or date period>
     *      2 NOTE <comment or [wikipedia de](<link>)>
     *
     * @return Collection<string>
     */
    
    public function historicEventsAll(): Collection
    {
        return new Collection([
 	    "1 EVEN Bill of Sail spends first full day on the hard\n2 TYPE Sad Circumstance\n2 DATE 24 OCT 2020",
            "1 EVEN Sir John A MacDonald\n2 TYPE Prime Minister of Canada\n2 DATE FROM 01 JUL 1867 TO 5 NOV 1873\ n2 NOTE Father of Confederation  Elected 1867 and 1872",
	    "1 EVEN Alexander MacKenzie\n2 TYPE Prime Minister of Canada\n2 DATE FROM 07 JUL 1873 TO 8 OCT 1878",
	    "1 EVEN Sir John A MacDonald\n2 TYPE Prime Minister of Canada\n2 DATE FROM 17 OCT 1878 TO 06 JUN 1891\ n2 NOTE Father of Confederation  Elected 1878, 1882, 1887, 1891 died in office",
	    "1 EVEN Sir John Abbott\n2 TYPE Prime Minister of Canada\n2 DATE FROM 16 JUN 1891 TO 24 NOV 1892\ n2 NOTE Appointed after MacDonald's death",
	    "1 EVEN Sir John Thompson\n2 TYPE Prime Minister of Canada\n2 DATE FROM 05 DEC 1892 TO 12 DEC 1894\ n2 NOTE Appointed",
	    "1 EVEN Sir MacKenzie Bowell\n2 TYPE Prime Minister of Canada\n2 DATE FROM 21 DEC 1894 TO 27 APR 1896\ n2 NOTE Appointed",
	    "1 EVEN Sir Charles Tupper\n2 TYPE Prime Minister of Canada\n2 DATE FROM 01 MAY 1896 TO 08 JUL 1896\ n2 NOTE Appointed",
	    "1 EVEN Sir Wilfred Laurier\n2 TYPE Prime Minister of Canada\n2 DATE FROM 11 JUL 1896 TO 06 OCT 1911\ n2 NOTE Elected 1896, 1900, 1904, 1908",
	    "1 EVEN Sir Robert Borden\n2 TYPE Prime Minister of Canada\n2 DATE FROM 10 OCT 1911 TO 10 JUL 1920\ n2 NOTE Elected 1911, 1917",
	    "1 EVEN Arthur Meighen\n2 TYPE Prime Minister of Canada\n2 DATE FROM 10 JUL 1920 TO 29 DEC 1921\ n2 NOTE Appointed",
	    "1 EVEN William Lyon MacKenzie King\n2 TYPE Prime Minister of Canada\n2 DATE FROM 29 DEC 1921 TO 28 JUN 1926\ n2 NOTE Elected 1921, 1925",
	    "1 EVEN Arthur Meighen\n2 TYPE Prime Minister of Canada\n2 DATE FROM 29 JUN 1926 TO 25 SEP 1926\ n2 NOTE Appointed",
	    "1 EVEN William Lyon MacKenzie King\n2 TYPE Prime Minister of Canada\n2 DATE FROM 25 SEP 1926 TO 07 AUG 1930\ n2 NOTE Elected 1926",
	    "1 EVEN William Lyon MacKenzie King\n2 TYPE Prime Minister of Canada\n2 DATE FROM 23 OCT 1935 TO 15 NOV 1948\ n2 NOTE Elected 1935, 1940, 1945",
	    "1 EVEN R B Bennett\n2 TYPE Prime Minister of Canada\n2 DATE FROM 07 Aug 1930 TO 23 OCT 1935\ n2 NOTE Elected 1930",
	    "1 EVEN Louis St Laurent\n2 TYPE Prime Minister of Canada\n2 DATE FROM 15 NOV 1948 TO 21 JUN 1957\ n2 NOTE Elected 1949, 1953",
	    "1 EVEN John George Diefenbaker\n2 TYPE Prime Minister of Canada\n2 DATE FROM 21 JUN 1957 TO 20 APR 1963\ n2 NOTE Elected 1957, 1958, 1962",
	    "1 EVEN Lester B Pearson\n2 TYPE Prime Minister of Canada\n2 DATE FROM 22 APR 1963 TO 20 APR 1968\ n2 NOTE Elected 1963, 1965",
	    "1 EVEN Pierre Elliott Trudeau\n2 TYPE Prime Minister of Canada\n2 DATE FROM 20 APR 1968 TO 03 JUN 1979\ n2 NOTE Elected 1968, 1972, 1974",
	    "1 EVEN Pierre Elliott Trudeau\n2 TYPE Prime Minister of Canada\n2 DATE FROM 03 MAR 1980 TO 29 JUN 1984\ n2 NOTE Elected 1980",
	    "1 EVEN Joseph Clark\n2 TYPE Prime Minister of Canada\n2 DATE FROM 04 JUN 1979 TO 02 MAR 1980\ n2 NOTE Elected 1979",
	    "1 EVEN  John Napier Turner\n2 TYPE Prime Minister of Canada\n2 DATE FROM 30 JUN 1984 TO 16 SEP 1984\ n2 NOTE Appointed",
	    "1 EVEN  Brian Mulroney\n2 TYPE Prime Minister of Canada\n2 DATE FROM 17 SEP 1984 TO 24 JUN 1993\ n2 NOTE Elected 1984, 1988",
	    "1 EVEN Kim Campbell \n2 TYPE Prime Minister of Canada\n2 DATE FROM 25 June 1993 TO 03 NOV 1993\ n2 NOTE Appointed",
	    "1 EVEN John Chretien\n2 TYPE Prime Minister of Canada\n2 DATE FROM 04 NOV 1993 TO 11 DEC 2003\ n2 NOTE Elected 1993, 1997, 2000",
	    "1 EVEN Paul Martin\n2 TYPE Prime Minister of Canada\n2 DATE FROM 12 DEC 2003 TO 05 FEB 2006\ n2 NOTE Elected 2004",
	    "1 EVEN Stephen Harper\n2 TYPE Prime Minister of Canada\n2 DATE FROM 06 FEB 2006 TO 03 NOV 2015\ n2 NOTE Elected 2006, 2008, 2011",
	    "1 EVEN Justin Trudeau\n2 TYPE Prime Minister of Canada\n2 DATE FROM 04 NOV 2016 \ n2 NOTE Elected 2015, 2019",
	    "1 EVEN Upper Canada\n2 TYPE Present day Ontario\n2 DATE FROM 26 DEC 1791 TO 10 FEB 1841\n2 NOTE Upper referred to its location relative to the St. Lawrence river",
	    "1 EVEN Province of Canada\n2 TYPE Present day Ontario & Quebec\n2 DATE FROM 11 FEB 1841 TO 01 JUL 1867\n2 NOTE 2 premieres 1 Ont and 1 Que",
        ]);
    }
    
};
